﻿Public Class Escr
    Private Sub btn_pesquisa_Click(sender As Object, e As EventArgs) Handles btn_pesquisa.Click
        Pesquisa.Show()


    End Sub

    Private Sub btn_insert_Click(sender As Object, e As EventArgs) Handles btn_insert.Click

    End Sub
End Class